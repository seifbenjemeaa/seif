/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

/**
 *
 * @author adm
 */
public class Commentaire {
    
   private int idCommentaire;
   private int idUser;
   private int idAnnonce;
   private String Commentaire;

    public Commentaire(int idCommentaire, int idUser, int idAnnonce, String Commentaire) {
        this.idCommentaire = idCommentaire;
        this.idUser = idUser;
        this.idAnnonce = idAnnonce;
        this.Commentaire = Commentaire;
    }

    public Commentaire(int idUser, int idAnnonce, String Commentaire) {
        this.idUser = idUser;
        this.idAnnonce = idAnnonce;
        this.Commentaire = Commentaire;
    }

    public Commentaire() {
           }

    public int getIdCommentaire() {
        return idCommentaire;
    }

    public void setIdCommentaire(int idCommentaire) {
        this.idCommentaire = idCommentaire;
    }

    public int getIdUser() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }

    public int getIdAnnonce() {
        return idAnnonce;
    }

    public void setIdAnnonce(int idAnnonce) {
        this.idAnnonce = idAnnonce;
    }

    public String getCommentaire() {
        return Commentaire;
    }

    public void setCommentaire(String Commentaire) {
        this.Commentaire = Commentaire;
    }

    @Override
    public String toString() {
        return "Commentaire{" + "idCommentaire=" + idCommentaire + ", idUser=" + idUser + ", idAnnonce=" + idAnnonce + ", Commentaire=" + Commentaire + '}';
    }
   
   
   
    
    
    
    
}
