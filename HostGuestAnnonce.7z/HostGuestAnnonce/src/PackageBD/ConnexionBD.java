/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PackageBD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author adm
 */
public class ConnexionBD {
    
  private static String url="jdbc:mysql://127.0.0.1:3306/hostguestbd";
    private static String login="root";
    private static String pwd="";
 
  private static Connection con;
  
   private ConnexionBD(){
    try {
      con =DriverManager.getConnection(url, login, pwd);
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }
   
   
   public static Connection getInstance(){
    if(con == null){
      new ConnexionBD();
      System.out.println("Connexion Etablie");
       
      
    }
    else
    { System.out.println("Connexion déja existante");}
    
    return con;   
  } 
    
}
