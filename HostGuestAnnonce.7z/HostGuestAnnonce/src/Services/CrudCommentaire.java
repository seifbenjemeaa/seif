/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import Entities.Commentaire;
import Interface.ICommentaire;
import PackageBD.ConnexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author adm
 */
public class CrudCommentaire implements ICommentaire{

   Connection con= ConnexionBD.getInstance();
    
  
    
 
   
    private static PreparedStatement pst;
     private static PreparedStatement pst1;
    private static ResultSet rs;
    
   
    
    
    @Override
    public void AjouterComentaire(Commentaire c) {
    
        String requete="insert into commentaire (idUser,idAnnonce,commentaire) values (?,?,?)";
      
       try {
           pst=con.prepareStatement(requete);
       
           pst.setInt(1,c.getIdUser());
           pst.setInt(2,c.getIdAnnonce());
           pst.setString(3,c.getCommentaire());
           pst.executeUpdate();
                   
       
       
       } catch (SQLException ex) {
           Logger.getLogger(CrudCommentaire.class.getName()).log(Level.SEVERE, null, ex);
       }
    
    
    }

    @Override
    public Commentaire AfficherComentaireParId(int idUser) {
    
        Commentaire c=new Commentaire();
        
        String requete="select * from commentaire where idUser ="+idUser+"";
       try {
           pst=con.prepareStatement(requete);
      
           rs=pst.executeQuery();
         while(rs.next()){
            
             c=new Commentaire(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getString(4));
             
             
             
             System.out.println();
        }
       
       } catch (SQLException ex) {
           Logger.getLogger(CrudCommentaire.class.getName()).log(Level.SEVERE, null, ex);
       }
        
       return c;
    
    
    }

    @Override
    public List<Commentaire> AfficherCommentaire() {
      
        List<Commentaire> C=new ArrayList<>();
        
        String requete="select * from commentaire";
       try {
           pst=con.prepareStatement(requete);
      
           rs=pst.executeQuery();
         while(rs.next()){
            Commentaire c=new Commentaire();
             c=new Commentaire(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getString(4));
             
             C.add(c);
             
             System.out.println();
        }
       
       } catch (SQLException ex) {
           Logger.getLogger(CrudCommentaire.class.getName()).log(Level.SEVERE, null, ex);
       }
        
       return C;
    
    }

    @Override
    public void SupprimerCommentaire(int idUser,int idCommentaire) {
        
       Commentaire c=new Commentaire();
        
        String requete="select * from commentaire where idCommentaire ="+idCommentaire+"";
       try {
           pst=con.prepareStatement(requete);
      
           rs=pst.executeQuery();
         while(rs.next()){
            
             c=new Commentaire(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getString(4));
             
             
             
             System.out.println();
        }
       
      
         
         if(c.getIdUser()==idUser){
         
        String requete1="DELETE FROM Commentaire WHERE idCommentaire = ?";
        pst1=con.prepareStatement(requete1);
        pst1.setInt(1, idCommentaire);
        pst1.executeUpdate();
         
         }
     } catch (SQLException ex) {
            Logger.getLogger(ConnexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
    
    
    
    
    
}
