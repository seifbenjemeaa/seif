/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import java.sql.Date;

/**
 *
 * @author adm
 */
public class Annonce {
    
    private int idAnnonce;
    private int idUser;
    private String Titre;
    private String Description;
    private boolean Disponibilite;
    private boolean Urgence;
    private String Adresse;
    private float Prix;
    private Date date_debut;
    private Date date_fin;
    private boolean Internet;
    private int nb_lits;
    private int nb_chambres;

    public Annonce(int idAnnonce, int idUser, String Titre, String Description, boolean Disponibilite, boolean Urgence, String Adresse, float Prix, Date date_debut, Date date_fin, boolean Internet, int nb_lits, int nb_chambres) {
        this.idAnnonce = idAnnonce;
        this.idUser = idUser;
        this.Titre = Titre;
        this.Description = Description;
        this.Disponibilite = Disponibilite;
        this.Urgence = Urgence;
        this.Adresse = Adresse;
        this.Prix = Prix;
        this.date_debut = date_debut;
        this.date_fin = date_fin;
        this.Internet = Internet;
        this.nb_lits = nb_lits;
        this.nb_chambres = nb_chambres;
    }
     public Annonce( int idUser, String Titre, String Description, boolean Disponibilite, boolean Urgence, String Adresse, float Prix, Date date_debut, Date date_fin, boolean Internet, int nb_lits, int nb_chambres) {
        
        this.idUser = idUser;
        this.Titre = Titre;
        this.Description = Description;
        this.Disponibilite = Disponibilite;
        this.Urgence = Urgence;
        this.Adresse = Adresse;
        this.Prix = Prix;
        this.date_debut = date_debut;
        this.date_fin = date_fin;
        this.Internet = Internet;
        this.nb_lits = nb_lits;
        this.nb_chambres = nb_chambres;
    }

    public Annonce() {
         }

    public int getIdAnnonce() {
        return idAnnonce;
    }

    public void setIdAnnonce(int idAnnonce) {
        this.idAnnonce = idAnnonce;
    }

    public int getIdUser() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }

    public String getTitre() {
        return Titre;
    }

    public void setTitre(String Titre) {
        this.Titre = Titre;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public boolean isDisponibilite() {
        return Disponibilite;
    }

    public void setDisponibilite(boolean Disponibilite) {
        this.Disponibilite = Disponibilite;
    }

    public boolean isUrgence() {
        return Urgence;
    }

    public void setUrgence(boolean Urgence) {
        this.Urgence = Urgence;
    }

    public String getAdresse() {
        return Adresse;
    }

    public void setAdresse(String Adresse) {
        this.Adresse = Adresse;
    }

    public float getPrix() {
        return Prix;
    }

    public void setPrix(float Prix) {
        this.Prix = Prix;
    }

    public Date getDate_debut() {
        return date_debut;
    }

    public void setDate_debut(Date date_debut) {
        this.date_debut = date_debut;
    }

    public Date getDate_fin() {
        return date_fin;
    }

    public void setDate_fin(Date date_fin) {
        this.date_fin = date_fin;
    }

    public boolean getInternet() {
        return Internet;
    }

    public void setInternet(boolean Internet) {
        this.Internet = Internet;
    }

    public int getNb_lits() {
        return nb_lits;
    }

    public void setNb_lits(int nb_lits) {
        this.nb_lits = nb_lits;
    }

    public int getNb_chambres() {
        return nb_chambres;
    }

    public void setNb_chambres(int nb_chambres) {
        this.nb_chambres = nb_chambres;
    }

    @Override
    public String toString() {
        return "Annonce{" + "idAnnonce=" + idAnnonce + ", idUser=" + idUser + ", Titre=" + Titre + ", Description=" + Description + ", Disponibilite=" + Disponibilite + ", Urgence=" + Urgence + ", Adresse=" + Adresse + ", Prix=" + Prix + ", date_debut=" + date_debut + ", date_fin=" + date_fin + ", Internet=" + Internet + ", nb_lits=" + nb_lits + ", nb_chambres=" + nb_chambres + '}';
    }
    
   
    
   
    
    
    
    
    
    
    
}
