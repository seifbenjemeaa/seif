/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import PackageBD.ConnexionBD;
import Entities.Annonce;
import Interface.InterfaceAnnonce;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import static java.util.Collections.list;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableView;

/**
 *
 * @author adm
 */
public class CrudAnnonce implements InterfaceAnnonce{
    
    Connection con= ConnexionBD.getInstance();
    
  
    
 
   
    private static PreparedStatement pst;
    private static ResultSet rs;
    
   
    ObservableList<ObservableList> obs;
    
    
    @Override
    public void AjouterAnnonce(Annonce A,String a) {
       
        
        String requete="insert into annonce (idUser,titre,description,disponibilite,urgence,adresse,prix,datedebut,datefin,internet,nbchambre,nblit,image) values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            
            
            
            pst=con.prepareStatement(requete);
            pst.setInt(1,A.getIdUser());
            pst.setString(2, A.getTitre());
            pst.setString(3, A.getDescription());
            pst.setBoolean(4, A.isDisponibilite());
            pst.setBoolean(5, A.isUrgence());
            pst.setString(6,A.getAdresse());
            pst.setFloat(7,A.getPrix());
            pst.setDate(8, A.getDate_debut());
            pst.setDate(9,A.getDate_fin());
            pst.setBoolean(10,A.getInternet());
            pst.setInt(11, A.getNb_chambres());
            pst.setInt(12,A.getNb_lits() );
            pst.setString(13,a);
            
            
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ConnexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    }

    
    

    @Override
    public void SupprimerAnnonce(Annonce A) throws SQLException {
        try { 
        
        String requete="DELETE FROM annonce WHERE idAnnonce = ?";
        pst=con.prepareStatement(requete);
        pst.setInt(1, A.getIdAnnonce());
        pst.executeUpdate();
     } catch (SQLException ex) {
            Logger.getLogger(ConnexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void ModifierAnnonce(Annonce A) throws SQLException {
       
            try{ 
             
             String requete="UPDATE annonce Set titre=?,description=?,disponibilite=?,urgence=?,adresse=?,prix=?,datedebut=?,datefin=?,internet=?,nbchambre=?,nblit=? where idAnnonce=? ";
             
            pst=con.prepareStatement(requete);
            
            pst.setString(1, A.getTitre());
            pst.setString(2, A.getDescription());
            pst.setBoolean(3, A.isDisponibilite());
            pst.setBoolean(4, A.isUrgence());
            pst.setString(5,A.getAdresse());
            pst.setFloat(6,A.getPrix());
            pst.setDate(7, A.getDate_debut());
            pst.setDate(8,A.getDate_fin());
            pst.setBoolean(9,A.getInternet());
            pst.setInt(10, A.getNb_chambres());
            pst.setInt(11,A.getNb_lits() );
             pst.setInt(12,A.getIdAnnonce());
             
             pst.executeUpdate();
             
            } catch (SQLException ex) {
            Logger.getLogger(ConnexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    
    }
     @Override
    public void SetImage(String url,int id) throws SQLException {
       
            try{ 
             
             String requete="UPDATE annonce Set image=? where idAnnonce=? ";
             
            pst=con.prepareStatement(requete);
            
            pst.setString(1, url);
            pst.setInt(12,id);
             
             pst.executeUpdate();
             
            } catch (SQLException ex) {
            Logger.getLogger(ConnexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    
    }
    
    

    @Override
    public Annonce RechercherAnnonce(Annonce A) throws SQLException {
     Annonce annonce = new Annonce();
        try{ 
        
        String requete="select * from annonce where idAnnonce="+A.getIdAnnonce()+" ";
        pst=con.prepareStatement(requete);
        rs=pst.executeQuery();
       
        while(rs.next()){
            annonce=new Annonce(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4),rs.getBoolean(5),rs.getBoolean(6),rs.getString(7),rs.getFloat(8),rs.getDate(9),rs.getDate(10),rs.getBoolean(11),rs.getInt(12),rs.getInt(13));
           //System.out.println(A);
        }    
     } catch (SQLException ex) {
            Logger.getLogger(ConnexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    return annonce;
    }

    @Override
    public List<Annonce> AfficherAnnonce()  {
        List<Annonce> L=new ArrayList<>();
        
        try {
        String requete="select * from annonce";
        pst=con.prepareStatement(requete);
        rs=pst.executeQuery();
        Annonce A;
        while(rs.next()){
            A=new Annonce(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4),rs.getBoolean(5),rs.getBoolean(6),rs.getString(7),rs.getFloat(8),rs.getDate(9),rs.getDate(10),rs.getBoolean(11),rs.getInt(12),rs.getInt(13));
           // System.out.println(A);
           L.add(A);
        }
         } catch (SQLException ex) {
            Logger.getLogger(ConnexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return L;
    }

    @Override
    public String GetImage(Annonce A) throws SQLException {
        
        String a="";
        
        try {
        String requete="select image from annonce where idAnnonce="+A.getIdAnnonce()+" ";
        pst=con.prepareStatement(requete);
        rs=pst.executeQuery();
        
        while(rs.next()){
           a=rs.getString(1);
           
        }
         } catch (SQLException ex) {
            Logger.getLogger(ConnexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return a;
                
    
    
    }
   
       @Override
    public void RechercheAvancee(String v, TableView tableProjet) {

        obs = FXCollections.observableArrayList();

        try {
            String sql = "SELECT * FROM annonce WHERE disponibilite LIKE '%" + v + "%' OR titre LIKE '%" + v + "%' OR nblit LIKE '%" + v + "%' OR prix LIKE '%" + v + "%' OR nbchambre LIKE '%" + v + "%' ORDER BY idAnnonce DESC";

            rs = con.createStatement().executeQuery(sql);

            while (rs.next()) {
                //preparation de ligne
                ObservableList<String> row = FXCollections.observableArrayList();
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    //iteration des colonnes
                    row.add(rs.getString(i));
                }
                // System.out.println("Row [1] added "+row );

                obs.addAll(row);

            }
            //ensuite l'ajout dans la table view
            tableProjet.setItems(obs);

        } catch (SQLException e) {
            System.out.println("Erreur " + e);
        }

    }
   
  @Override
    public List<Annonce> RechercheAvancee2(String v) {

       

        
           
           List<Annonce> L=new ArrayList<>();
        
        try {
        String requete = "SELECT * FROM annonce WHERE disponibilite LIKE '%" + v + "%' OR titre LIKE '%" + v + "%' OR nblit LIKE '%" + v + "%' OR prix LIKE '%" + v + "%' OR nbchambre LIKE '%" + v + "%' ORDER BY idAnnonce DESC";

        pst=con.prepareStatement(requete);
        rs=pst.executeQuery();
        Annonce A;
        while(rs.next()){
            A=new Annonce(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4),rs.getBoolean(5),rs.getBoolean(6),rs.getString(7),rs.getFloat(8),rs.getDate(9),rs.getDate(10),rs.getBoolean(11),rs.getInt(12),rs.getInt(13));
           // System.out.println(A);
           L.add(A);
        }
         } catch (SQLException ex) {
            Logger.getLogger(ConnexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return L;

    }

    @Override
    public List<Annonce> DernieresAnnonces() {
        
     List<Annonce> L=new ArrayList<>();
        
        try {
        String requete="select * from annonce order by idAnnonce desc limit 4";
        pst=con.prepareStatement(requete);
        rs=pst.executeQuery();
        Annonce A;
        while(rs.next()){
            A=new Annonce(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4),rs.getBoolean(5),rs.getBoolean(6),rs.getString(7),rs.getFloat(8),rs.getDate(9),rs.getDate(10),rs.getBoolean(11),rs.getInt(12),rs.getInt(13));
           // System.out.println(A);
           L.add(A);
        }
         } catch (SQLException ex) {
            Logger.getLogger(ConnexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return L;
    
    }
    
  
}
