/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hostguestannonce;

import Entities.Annonce;
import Services.CrudAnnonce;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXTextField;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import java.util.List;
import java.util.Observable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
/**
 * FXML Controller class
 *
 * @author adm
 */
public class FXMLAnnonceController implements Initializable {

    /**
     * Initializes the controller class.
     */
     @FXML
    private JFXButton b2;

    @FXML
    private AnchorPane anchorpane;

    @FXML
    private TableColumn<Annonce, Float> prix;

    @FXML
    private TableColumn<Annonce, String> titre;

    @FXML
    private TableColumn<Annonce, Integer> nblit;

    @FXML
    private TableColumn<Annonce, String> adresse;

    @FXML
    private TableColumn<Annonce, Boolean> urgence;

    @FXML
    private TableColumn<Annonce, String> descriprion;

    @FXML
    private TableColumn<Annonce, Boolean> internet;

    @FXML
    private JFXButton b1;

    @FXML
    private TableView<Annonce> table;
    
    @FXML
    private TableColumn<Annonce, Boolean> dispo;

    @FXML
    private TableColumn<Annonce, Integer> nbchambre;
    
    @FXML
    private JFXDrawer dawer;
    
    @FXML
    private VBox vbox;
    
    @FXML
    private JFXTextField recherche;
    
    
    
    @FXML
    public void Retour(ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
         
        Scene scene = new Scene(root);
        
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();  
        
        app_stage.setScene(scene);
        
        app_stage.show();
    }
    
    @FXML
    public void Modifier(ActionEvent event) throws IOException{
       
        
        Annonce a=new  Annonce();
         
        a = table.getSelectionModel().getSelectedItem();
        
        FXMLLoader loader=new FXMLLoader();
       FXMLmodifierAnnonceController f=(FXMLmodifierAnnonceController) loader.getController();
        
        System.out.println(a.getDate_debut());
        
        f=new FXMLmodifierAnnonceController();
       
        f.setAnnonce(a);
        
       
        
        Parent root = FXMLLoader.load(getClass().getResource("FXMLmodifierAnnonce.fxml"));
         
        Scene scene = new Scene(root);
        
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();  
        
        app_stage.setScene(scene);
        
        app_stage.show();
    
    
    
    }
     @FXML
    public void Ajout(ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("FXMLAjoutAnnonce.fxml"));
         
        Scene scene = new Scene(root);
        
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();  
        
        app_stage.setScene(scene);
        
        app_stage.show();
    }
    
     
   
    
    
    @FXML
    public void Supprimer(ActionEvent event) throws SQLException{
        
        Annonce a=new  Annonce();
         a = table.getSelectionModel().getSelectedItem();
        
         
        CrudAnnonce CA=new CrudAnnonce();
        
        CA.SupprimerAnnonce(a);
         
        Parent root;
         try {
             root = FXMLLoader.load(getClass().getResource("FXMLAnnonce.fxml"));
        
         
        Scene scene = new Scene(root);
        
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();  
        
        app_stage.setScene(scene);
        
        app_stage.show();
         } catch (IOException ex) {
             Logger.getLogger(FXMLAnnonceController.class.getName()).log(Level.SEVERE, null, ex);
         }
    }
    
    
    
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        dawer.setSidePane(vbox);
        
        table.setOnMousePressed(new EventHandler<MouseEvent>() {
    @Override 
    public void handle(MouseEvent event) {
        if (event.isPrimaryButtonDown() && event.getClickCount() == 1) {
            if (dawer.isShown()) {

                dawer.close();

            } else {
                dawer.open();
            }                   
       
        }
    }
});
        
        
        
        
        
        
        
        CrudAnnonce CA=new CrudAnnonce();
        List<Annonce> list=CA.AfficherAnnonce();
        ObservableList<Annonce> lst=FXCollections.observableArrayList();
        for ( int i=0;i<list.size();i++)
        {
            lst.add(list.get(i)); }
             titre.setCellValueFactory(new PropertyValueFactory<Annonce,String>("titre"));
             adresse.setCellValueFactory(new PropertyValueFactory<Annonce,String>("adresse"));
             descriprion.setCellValueFactory(new PropertyValueFactory<Annonce,String>("description"));
             dispo.setCellValueFactory(new PropertyValueFactory<Annonce,Boolean>("disponibilite"));
             urgence.setCellValueFactory(new PropertyValueFactory<Annonce,Boolean>("urgence"));
             prix.setCellValueFactory(new PropertyValueFactory<Annonce,Float>("prix"));
             nbchambre.setCellValueFactory(new PropertyValueFactory<Annonce,Integer>("nb_chambres"));
             nblit.setCellValueFactory(new PropertyValueFactory<Annonce,Integer>("nb_lits"));
             internet.setCellValueFactory(new PropertyValueFactory<Annonce,Boolean>("internet"));
             
             //System.out.println(lst);
             table.setItems(lst);
            
            
       
        
        
        // TODO
    }    
    

@FXML
    private void chercher(javafx.scene.input.KeyEvent event) {
       
        table.refresh();
         CrudAnnonce CA=new CrudAnnonce();
        List<Annonce> list=CA.RechercheAvancee2(recherche.getText());
        ObservableList<Annonce> lst=FXCollections.observableArrayList();
        for ( int i=0;i<list.size();i++)
        {
            lst.add(list.get(i)); }
             titre.setCellValueFactory(new PropertyValueFactory<Annonce,String>("titre"));
             adresse.setCellValueFactory(new PropertyValueFactory<Annonce,String>("adresse"));
             descriprion.setCellValueFactory(new PropertyValueFactory<Annonce,String>("description"));
             dispo.setCellValueFactory(new PropertyValueFactory<Annonce,Boolean>("disponibilite"));
             urgence.setCellValueFactory(new PropertyValueFactory<Annonce,Boolean>("urgence"));
             prix.setCellValueFactory(new PropertyValueFactory<Annonce,Float>("prix"));
             nbchambre.setCellValueFactory(new PropertyValueFactory<Annonce,Integer>("nb_chambres"));
             nblit.setCellValueFactory(new PropertyValueFactory<Annonce,Integer>("nb_lits"));
             internet.setCellValueFactory(new PropertyValueFactory<Annonce,Boolean>("internet"));
             
             //System.out.println(lst);
             table.setItems(lst);
            
            
      
    
    }

    


}
