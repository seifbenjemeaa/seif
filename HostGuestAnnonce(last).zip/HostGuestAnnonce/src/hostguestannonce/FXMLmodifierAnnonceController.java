/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hostguestannonce;

import Entities.Annonce;
import PackageBD.ConnexionBD;
import Services.CrudAnnonce;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXToggleButton;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashSet;


import java.util.ResourceBundle;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author adm
 */
public class FXMLmodifierAnnonceController implements Initializable {

    
     @FXML
    private JFXTextArea desctiion;

    @FXML
    private JFXTextField nbchambres;

    @FXML
    private JFXTextField prix;

    @FXML
    private JFXTextField titre;

    @FXML
    private JFXTextField adresse;

    @FXML
    private JFXTextField nblits;

    @FXML
    private DatePicker D1;

    @FXML
    private DatePicker D2;

    @FXML
    private JFXToggleButton internet;
    
     @FXML
    private JFXToggleButton urgence;
    @FXML
    private JFXButton b2;
    @FXML
    private ImageView image;
    @FXML
    private JFXButton btn1;
    @FXML
    private JFXButton b1;
    
    File file;
    /**
     * Initializes the controller class.
     */
    
   
     
     
    static Annonce annonce=new Annonce();

    public Annonce getAnnonce() {
        return annonce;
    }

    public void setAnnonce(Annonce annonce) {
        this.annonce = annonce;
    }
   
    @FXML
    public void ChargerImage(ActionEvent event) throws IOException {
        FileChooser fileChooser = new FileChooser();
        //FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
        //fileChooser.getExtensionFilters().add(extFilter);
         file = fileChooser.showOpenDialog(image.getScene().getWindow());
        if (file != null) {
            Image m=new Image(file.toURI().toString(), 100, 150, true, true);
            
            image.setImage(m);
            image.setFitWidth(240);
            image.setFitHeight(180);
/*
            Circle clip = new Circle(photo.getFitWidth() / 2,
                    photo.getFitHeight() / 2,
                    85);
            photo.setClip(clip);
          String S=  (String) photo.getUserData();*/
        }
        System.out.println(file);
    }
    
     @FXML
    public void ModifierAnnonce(ActionEvent event) throws IOException{
        
       
        float pri = Float.parseFloat(prix.getText());
        int lits = Integer.parseInt(nblits.getText());
        int chambres=Integer.parseInt(nbchambres.getText());
        
         System.out.println(prix.getText());
         System.out.println(titre.getText());
         
        
        // java.util.Date date_util = new java.util.Date(12/12/2012);
 

        //java.sql.Date date_sql = new java.sql.Date(date_util.getTime());
        //LocalDate dateinput;
        //dateinput = LocalDate.now();
        Date date1 = java.sql.Date.valueOf(D1.getValue());
        Date date2 = java.sql.Date.valueOf(D2.getValue());
        
         Annonce b=new Annonce(annonce.getIdAnnonce(),0,titre.getText(), desctiion.getText(),true, urgence.isSelected(), adresse.getText(), pri, date1, date2, internet.isSelected(), lits, chambres);
         System.out.println(b);
         
         CrudAnnonce ca=new CrudAnnonce();
         try{
         ca.ModifierAnnonce(b);
         ca.SetImage(file.toURI().toString(),annonce.getIdAnnonce());
         } catch (SQLException ex) {
            Logger.getLogger(ConnexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
         
     //dateinput
        
       
        
        
        
        /* 
        try{
        CrudAnnonce CA=new CrudAnnonce();
        
        CA.ModifierAnnonce(a);
         
        } catch (SQLException ex) {
            Logger.getLogger(ConnexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
        */
        
        
         Parent root = FXMLLoader.load(getClass().getResource("FXMLAnnonce.fxml"));
         
        Scene scene = new Scene(root);
        
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();  
        
        app_stage.setScene(scene);
        
        app_stage.show();
        
    }
    
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
      
     titre.setText(annonce.getTitre());
     adresse.setText(annonce.getAdresse());
     desctiion.setText(annonce.getDescription());
    
///
     prix.setText(Float.toString(annonce.getPrix()));
     nbchambres.setText(Integer.toString(annonce.getNb_chambres()));
     nblits.setText(Integer.toString(annonce.getNb_lits()));
     ///   
      Date date1 = annonce.getDate_debut();
      Date date2 = annonce.getDate_fin();
     ///
      LocalDate localD = date1.toLocalDate();
      LocalDate localD2 = date2.toLocalDate();
      D1.setValue(localD);
      D2.setValue(localD2);
     /// 
   
     internet.setSelected(annonce.getInternet());
     urgence.setSelected(annonce.isUrgence());
     ///
     CrudAnnonce CA=new CrudAnnonce();
     Image m = null;
         try {
              m = new Image(CA.GetImage(annonce), 100, 150, true, true);
         } catch (SQLException ex) {
             Logger.getLogger(FXMLmodifierAnnonceController.class.getName()).log(Level.SEVERE, null, ex);
         }
        
            
     image.setImage(m);
   
        
        /*  System.out.println("aaaa");
        System.out.println(annonce);
    
       
        
        
        test.setText(annonce.getDescription());
        
        test2.setText(annonce.getDescription());
    
        System.out.println("teeeeest");
        */
    }    
    
}
