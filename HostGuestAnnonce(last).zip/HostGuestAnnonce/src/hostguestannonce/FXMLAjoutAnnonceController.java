/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hostguestannonce;

import Entities.Annonce;
import Services.CrudAnnonce;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXToggleButton;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author adm
 */
public class FXMLAjoutAnnonceController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private ImageView image;
    @FXML
    private JFXButton btn1;
    
       @FXML
    private JFXButton b2;

    @FXML
    private JFXTextField nbchambres;

    @FXML
    private JFXTextField prix;

    @FXML
    private JFXTextField titre;

    @FXML
    private JFXTextField adresse;

    @FXML
    private JFXTextArea description;

    @FXML
    private JFXToggleButton urgence;

    @FXML
    private JFXTextField nblits;

    @FXML
    private DatePicker D1;

    @FXML
    private DatePicker D2;

    @FXML
    private JFXToggleButton internet;

    @FXML
    private JFXButton b1;

     private File file;
    
    @FXML
    public void AjouterAnnonce(ActionEvent event) throws IOException{
        
       
        float pri = Float.parseFloat(prix.getText());
        int lits = Integer.parseInt(nblits.getText());
        int chambres=Integer.parseInt(nbchambres.getText());
        
        // java.util.Date date_util = new java.util.Date(12/12/2012);
 

        //java.sql.Date date_sql = new java.sql.Date(date_util.getTime());
        //LocalDate dateinput;
        //dateinput = LocalDate.now();
        Date date1 = java.sql.Date.valueOf(D1.getValue());
         Date date2 = java.sql.Date.valueOf(D2.getValue());
        //dateinput
        
        Annonce a=new Annonce(0,titre.getText(), description.getText(), true,urgence.isSelected(), adresse.getText(), pri, date1,date2,internet.isSelected(),chambres,lits);
        
        System.out.println(a);
        
        CrudAnnonce CA=new CrudAnnonce();
        
        CA.AjouterAnnonce(a,file.toURI().toString());
        
        
         Parent root = FXMLLoader.load(getClass().getResource("FXMLAnnonce.fxml"));
         
        Scene scene = new Scene(root);
        
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();  
        
        app_stage.setScene(scene);
        
        app_stage.show();
        
    }
    @FXML
    public void ChargerImage(ActionEvent event) throws IOException {
        FileChooser fileChooser = new FileChooser();
        //FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
        //fileChooser.getExtensionFilters().add(extFilter);
         file = fileChooser.showOpenDialog(image.getScene().getWindow());
        if (file != null) {
            Image m=new Image(file.toURI().toString(), 100, 150, true, true);
            
            image.setImage(m);
            image.setFitWidth(240);
            image.setFitHeight(180);
/*
            Circle clip = new Circle(photo.getFitWidth() / 2,
                    photo.getFitHeight() / 2,
                    85);
            photo.setClip(clip);
          String S=  (String) photo.getUserData();*/
        }
        System.out.println(file);
    }
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
