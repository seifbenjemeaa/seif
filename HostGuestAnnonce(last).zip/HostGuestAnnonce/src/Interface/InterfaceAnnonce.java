/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Entities.Annonce;
import java.sql.SQLException;
import java.util.List;
import javafx.scene.control.TableView;

/**
 *
 * @author adm
 */
public interface InterfaceAnnonce {
    
   public void AjouterAnnonce(Annonce A,String a);
   public List<Annonce> AfficherAnnonce();
   public void SupprimerAnnonce(Annonce A)throws SQLException;
   public void ModifierAnnonce(Annonce A)throws SQLException;
   public void SetImage(String url,int id)throws SQLException;
   public Annonce RechercherAnnonce(Annonce A)throws SQLException; 
   public String GetImage(Annonce A)throws SQLException;
    public void RechercheAvancee(String v, TableView tableProjet);
    public List<Annonce> RechercheAvancee2(String v) ;
    public List<Annonce> DernieresAnnonces() ;

}
