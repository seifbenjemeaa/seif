/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Entities.Commentaire;
import java.util.List;

/**
 *
 * @author adm
 */
public interface ICommentaire {
    
    public void AjouterComentaire(Commentaire c);
    public Commentaire AfficherComentaireParId(int idUser);
    public List<Commentaire> AfficherCommentaire();
    public void SupprimerCommentaire(int idUser,int idCommentaire);
    
    
    
}
